var group__service =
[
    [ "Config", "group__config.html", "group__config" ],
    [ "Processing", "group__processing.html", "group__processing" ],
    [ "Sensor", "group__sensor.html", "group__sensor" ]
];