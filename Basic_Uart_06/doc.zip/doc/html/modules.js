var modules =
[
    [ "Definitions", "group__definitions.html", "group__definitions" ],
    [ "Distance Detector", "group__Distance.html", "group__Distance" ],
    [ "Presence Detector", "group__Presence.html", "group__Presence" ],
    [ "RSS", "group__rss.html", "group__rss" ],
    [ "Service", "group__service.html", "group__service" ]
];