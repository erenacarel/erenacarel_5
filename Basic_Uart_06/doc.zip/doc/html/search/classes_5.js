var searchData=
[
  ['presence_5fdetector_5fcontext_5ft_2108',['presence_detector_context_t',['../structpresence__detector__context__t.html',1,'']]],
  ['presence_5fdetector_5fresources_5ft_2109',['presence_detector_resources_t',['../structpresence__detector__resources__t.html',1,'']]],
  ['print_5fbuffer_5ft_2110',['print_buffer_t',['../structprint__buffer__t.html',1,'']]]
];
