var searchData=
[
  ['optimization_1324',['optimization',['../structacc__hal__a121__t.html#ae7721dcf6b8be2b324c759491beb4de6',1,'acc_hal_a121_t']]],
  ['ospeedr_1325',['OSPEEDR',['../structgpio__config__t.html#a80c187337c56f0f2a52d155b12b436d8',1,'gpio_config_t']]],
  ['otyper_1326',['OTYPER',['../structgpio__config__t.html#ab08d22c5f1c07a1eadcd826456771270',1,'gpio_config_t']]],
  ['out_5ffct_5ftype_1327',['out_fct_type',['../printf_8c.html#ac4a1ad6d5e0eae2f65ab59703847359a',1,'printf.c']]],
  ['out_5ffct_5fwrap_5ftype_1328',['out_fct_wrap_type',['../structout__fct__wrap__type.html',1,'']]],
  ['out_5ffunc_1329',['out_func',['../acc__wrap__printf_8c.html#a8c1c7b4f11ff1b925523dde34884d99c',1,'acc_wrap_printf.c']]]
];
