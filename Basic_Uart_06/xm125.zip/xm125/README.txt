This package contains example source code, a makefile based build system, libraries, pre-built
binaries and documentation in order to start developing your own A121 radar applications
for the xm125 module.

Please see 'doc/XM125 Software User Guide.pdf' in order to get started with application development.

For more documentation please visit https://docs.acconeer.com/ or https://developer.acconeer.com

To view release notes use the following link: https://developer.acconeer.com/a121-sw-release-notes/
