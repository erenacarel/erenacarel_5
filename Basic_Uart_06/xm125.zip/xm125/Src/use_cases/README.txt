This folder contains example apps and reference apps, which can also be found in Acconeer Exploration Tool

For evaluation install Acconeer Exploration Tool via pip (https://docs.acconeer.com/en/latest/exploration_tool/installation_and_setup.html).

For python reference visit https://github.com/acconeer/acconeer-python-exploration/

For more documentation please visit https://docs.acconeer.com/
